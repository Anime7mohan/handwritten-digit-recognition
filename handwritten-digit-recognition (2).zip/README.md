# Handwritten Digit Recognition with Deep Learning

This project uses Convolutional Neural Networks (CNNs) and Support Vector Machines (SVMs) to recognize handwritten digits from the MNIST dataset.

## Features
- Data loading and preprocessing
- CNN model achieving ~99% accuracy
- SVM classifier for comparison
- EDA and result visualization

## Technologies Used
- Python
- TensorFlow/Keras
- scikit-learn
- matplotlib, seaborn

## Setup
```bash
pip install -r requirements.txt
python main.py
```
